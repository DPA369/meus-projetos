a = 'LinkedIn Learning'
print('A plataforma do curso é: ' + a)
