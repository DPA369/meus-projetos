a = 1
b = 2

print(a + b)